# Document Summary Assistant

Upload a PDF or a scanned image, and get back a short summary plus key points.
Built with Next.js 14 (App Router).

## How it works

1. **Upload** — drag-and-drop or file picker accepts PDF, PNG, JPG, WEBP.
2. **Extraction** (`/api/extract`)
   - PDFs → parsed with `pdf-parse`.
   - Images → OCR'd with `tesseract.js`.
3. **Summarization** (`/api/summarize`)
   - If `ANTHROPIC_API_KEY` is set, Claude generates the summary and key points, respecting the chosen length (short / medium / long).
   - If no key is set, the app **automatically falls back** to a built-in extractive summarizer (word-frequency sentence scoring) — so the app is fully functional with zero paid services, satisfying the "any free tier" requirement.
4. **Result** is rendered with a summary paragraph and a bulleted key-points list.

## Run locally

```bash
npm install
cp .env.example .env.local   # optional: add ANTHROPIC_API_KEY for higher-quality summaries
npm run dev
```

Visit `http://localhost:3000`.

## Deploy

### Vercel (recommended)
1. Push this repo to GitHub.
2. Import it at [vercel.com/new](https://vercel.com/new).
3. (Optional) Add `ANTHROPIC_API_KEY` under Project Settings → Environment Variables.
4. Deploy. Vercel auto-detects Next.js — no config needed.

### Netlify
1. Push to GitHub, then "Add new site → Import an existing project".
2. Build command: `next build` · Publish directory: handled by the official Next.js Netlify plugin (auto-detected).
3. Add `ANTHROPIC_API_KEY` under Site settings → Environment variables if desired.

> **Note on OCR:** `tesseract.js` downloads its language model from a CDN on first use in a serverless function. This works fine on Vercel/Netlify (they have outbound internet access) but will fail in network-restricted sandboxes. If your OCR requests time out on a cold start, retry once — the model is cached after the first successful run, or bundle the `eng.traineddata` file locally and pass `langPath` to `createWorker` for fully offline OCR.

## Project structure

```
app/
  page.js                 – upload UI, length selector, results
  api/extract/route.js    – PDF parsing + OCR
  api/summarize/route.js  – Claude summarization + extractive fallback
lib/
  extractive-summarizer.js – no-API-key fallback summarizer
```

## Design decisions

- **Graceful degradation over hard dependency.** The app never requires a paid API key to function — it degrades to a local algorithm instead of breaking.
- **Serverless-friendly.** Both API routes run on the Node.js runtime (not Edge) since `pdf-parse` and `tesseract.js` need Node APIs.
- **Minimal state.** All state lives in a single client component (`useState`) — no external state library needed for this scope.

## Known limitations

- Very large PDFs (100+ pages) may exceed serverless function time limits; text is truncated to ~15,000 characters before summarization.
- OCR accuracy depends on scan quality; skewed or low-resolution scans will extract poorly.
- No persistence — summaries aren't saved between sessions (out of scope for the assignment).
