import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

async function extractFromPdf(buffer) {
  const pdfParse = (await import("pdf-parse")).default;
  const data = await pdfParse(buffer);
  return data.text;
}

async function extractFromImage(buffer) {
  const { createWorker } = await import("tesseract.js");
  const worker = await createWorker("eng");
  try {
    const {
      data: { text },
    } = await worker.recognize(buffer);
    return text;
  } finally {
    await worker.terminate();
  }
}

export async function POST(req) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!file) {
      return NextResponse.json({ error: "No file was uploaded." }, { status: 400 });
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    let text = "";
    if (file.type === "application/pdf") {
      text = await extractFromPdf(buffer);
    } else if (file.type.startsWith("image/")) {
      text = await extractFromImage(buffer);
    } else {
      return NextResponse.json(
        { error: "Unsupported file type. Upload a PDF or an image." },
        { status: 400 }
      );
    }

    text = text.replace(/\u0000/g, "").trim();

    if (!text || text.length < 10) {
      return NextResponse.json(
        { error: "Couldn't find readable text in that file. Try a clearer scan or a different file." },
        { status: 422 }
      );
    }

    return NextResponse.json({ text });
  } catch (err) {
    console.error("extract error", err);
    return NextResponse.json(
      { error: "Failed to extract text from the document." },
      { status: 500 }
    );
  }
}
