import { NextResponse } from "next/server";
import { extractiveSummarize } from "../../../lib/extractive-summarizer";

export const runtime = "nodejs";
export const maxDuration = 60;

const MAX_INPUT_CHARS = 15000; // keep prompt small enough for a free-tier API call

const LENGTH_INSTRUCTIONS = {
  short: "Write a short summary of 3-4 sentences.",
  medium: "Write a medium-length summary of 1-2 short paragraphs.",
  long: "Write a thorough summary covering all major sections in detail (several paragraphs).",
};

async function summarizeWithClaude(text, length) {
  const Anthropic = (await import("@anthropic-ai/sdk")).default;
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

  const truncated = text.slice(0, MAX_INPUT_CHARS);
  const prompt = `You are summarizing a document for someone deciding whether to read it in full.

${LENGTH_INSTRUCTIONS[length] || LENGTH_INSTRUCTIONS.medium}

Then list 3-6 key points as short bullet lines.

Respond ONLY with valid JSON in this exact shape, nothing else:
{"summary": "...", "keyPoints": ["...", "..."]}

Document:
"""
${truncated}
"""`;

  const response = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1000,
    messages: [{ role: "user", content: prompt }],
  });

  const textBlock = response.content.find((c) => c.type === "text");
  if (!textBlock) throw new Error("Empty response from model");

  const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(cleaned);
  return {
    summary: parsed.summary,
    keyPoints: parsed.keyPoints || [],
    engine: "claude",
  };
}

export async function POST(req) {
  try {
    const { text, length } = await req.json();
    if (!text || typeof text !== "string") {
      return NextResponse.json({ error: "No text provided to summarize." }, { status: 400 });
    }

    const safeLength = ["short", "medium", "long"].includes(length) ? length : "medium";

    if (process.env.ANTHROPIC_API_KEY) {
      try {
        const result = await summarizeWithClaude(text, safeLength);
        return NextResponse.json(result);
      } catch (err) {
        console.error("Claude summarization failed, falling back:", err);
        // fall through to extractive fallback below
      }
    }

    const fallback = extractiveSummarize(text, safeLength);
    return NextResponse.json({ ...fallback, engine: "extractive-fallback" });
  } catch (err) {
    console.error("summarize error", err);
    return NextResponse.json({ error: "Failed to generate a summary." }, { status: 500 });
  }
}
