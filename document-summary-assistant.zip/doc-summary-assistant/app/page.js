"use client";

import { useCallback, useRef, useState } from "react";

const LENGTHS = [
  { id: "short", label: "Short", hint: "3–4 sentences" },
  { id: "medium", label: "Medium", hint: "1–2 paragraphs" },
  { id: "long", label: "Long", hint: "Full detail" },
];

export default function Home() {
  const [file, setFile] = useState(null);
  const [stage, setStage] = useState("idle"); // idle | extracting | summarizing | done | error
  const [length, setLength] = useState("medium");
  const [extractedText, setExtractedText] = useState("");
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef(null);

  const reset = () => {
    setFile(null);
    setStage("idle");
    setExtractedText("");
    setSummary(null);
    setError("");
  };

  const handleFile = useCallback((f) => {
    if (!f) return;
    const okTypes = ["application/pdf", "image/png", "image/jpeg", "image/jpg", "image/webp"];
    if (!okTypes.includes(f.type)) {
      setError("Please upload a PDF or an image file (PNG, JPG, WEBP).");
      return;
    }
    setError("");
    setFile(f);
    setSummary(null);
    setExtractedText("");
    setStage("idle");
  }, []);

  const onDrop = useCallback(
    (e) => {
      e.preventDefault();
      setDragActive(false);
      const f = e.dataTransfer.files?.[0];
      handleFile(f);
    },
    [handleFile]
  );

  const runPipeline = async () => {
    if (!file) return;
    setError("");
    try {
      setStage("extracting");
      const form = new FormData();
      form.append("file", file);
      const extractRes = await fetch("/api/extract", { method: "POST", body: form });
      const extractData = await extractRes.json();
      if (!extractRes.ok) throw new Error(extractData.error || "Couldn't read that file.");
      setExtractedText(extractData.text);

      setStage("summarizing");
      const sumRes = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: extractData.text, length }),
      });
      const sumData = await sumRes.json();
      if (!sumRes.ok) throw new Error(sumData.error || "Couldn't generate a summary.");
      setSummary(sumData);
      setStage("done");
    } catch (err) {
      setError(err.message || "Something went wrong.");
      setStage("error");
    }
  };

  return (
    <main style={styles.page}>
      <div style={styles.wrap}>
        <header style={styles.header}>
          <div style={styles.headerMark} aria-hidden="true" />
          <div>
            <h1 style={styles.title}>Document Summary Assistant</h1>
            <p style={styles.subtitle}>
              Drop in a PDF or a scanned page. Get back the parts worth reading.
            </p>
          </div>
        </header>

        <section
          style={{
            ...styles.dropzone,
            borderColor: dragActive ? "var(--mark)" : "var(--hairline)",
            background: dragActive ? "var(--mark-soft)" : "var(--paper-raised)",
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={onDrop}
        >
          {!file ? (
            <>
              <p style={styles.dropText}>
                Drag a file here, or{" "}
                <button style={styles.linkButton} onClick={() => inputRef.current?.click()}>
                  choose one
                </button>
              </p>
              <p style={styles.dropHint}>PDF, PNG, JPG, or WEBP · scanned pages OK</p>
              <input
                ref={inputRef}
                type="file"
                accept=".pdf,.png,.jpg,.jpeg,.webp"
                style={{ display: "none" }}
                onChange={(e) => handleFile(e.target.files?.[0])}
              />
            </>
          ) : (
            <div style={styles.fileRow}>
              <div style={styles.fileMeta}>
                <span style={styles.fileName}>{file.name}</span>
                <span style={styles.fileSize}>{(file.size / 1024).toFixed(0)} KB</span>
              </div>
              <button style={styles.clearButton} onClick={reset}>
                Remove
              </button>
            </div>
          )}
        </section>

        {file && (
          <section style={styles.controls}>
            <div style={styles.lengthRow}>
              <span style={styles.lengthLabel}>Summary length</span>
              <div style={styles.lengthOptions}>
                {LENGTHS.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setLength(opt.id)}
                    style={{
                      ...styles.lengthPill,
                      ...(length === opt.id ? styles.lengthPillActive : {}),
                    }}
                    title={opt.hint}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <button
              style={{
                ...styles.primaryButton,
                opacity: stage === "extracting" || stage === "summarizing" ? 0.6 : 1,
              }}
              onClick={runPipeline}
              disabled={stage === "extracting" || stage === "summarizing"}
            >
              {stage === "extracting"
                ? "Reading document…"
                : stage === "summarizing"
                ? "Writing summary…"
                : "Summarize"}
            </button>
          </section>
        )}

        {error && <p style={styles.error}>{error}</p>}

        {summary && (
          <section style={styles.result}>
            <div style={styles.resultHeader}>
              <span style={styles.resultEyebrow}>Summary</span>
              <span style={styles.resultMeta}>
                {extractedText.split(/\s+/).length.toLocaleString()} words read
              </span>
            </div>
            <p style={styles.summaryText}>{summary.summary}</p>
            {summary.keyPoints?.length > 0 && (
              <div style={styles.keyPoints}>
                <span style={styles.resultEyebrow}>Key points</span>
                <ul style={styles.keyList}>
                  {summary.keyPoints.map((kp, i) => (
                    <li key={i} style={styles.keyItem}>
                      {kp}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        )}
      </div>
    </main>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    padding: "48px 20px 80px",
    display: "flex",
    justifyContent: "center",
  },
  wrap: { width: "100%", maxWidth: 640 },
  header: {
    display: "flex",
    gap: 16,
    alignItems: "flex-start",
    marginBottom: 36,
  },
  headerMark: {
    width: 6,
    height: 44,
    background: "var(--mark)",
    marginTop: 6,
    flexShrink: 0,
  },
  title: {
    fontFamily: "'Source Serif 4', Georgia, serif",
    fontWeight: 600,
    fontSize: 32,
    lineHeight: 1.15,
    margin: "0 0 8px",
    color: "var(--ink)",
  },
  subtitle: {
    margin: 0,
    color: "var(--ink-soft)",
    fontSize: 15.5,
    lineHeight: 1.5,
    maxWidth: 46 + "ch",
  },
  dropzone: {
    border: "1.5px dashed var(--hairline)",
    borderRadius: 4,
    padding: "36px 24px",
    textAlign: "center",
    transition: "border-color 120ms ease, background 120ms ease",
  },
  dropText: { margin: "0 0 6px", fontSize: 15.5, color: "var(--ink)" },
  dropHint: { margin: 0, fontSize: 13, color: "var(--ink-soft)" },
  linkButton: {
    background: "none",
    border: "none",
    padding: 0,
    color: "var(--mark)",
    textDecoration: "underline",
    textUnderlineOffset: 3,
    cursor: "pointer",
    fontSize: "inherit",
    fontFamily: "inherit",
  },
  fileRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  fileMeta: { display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 2 },
  fileName: { fontSize: 15, fontWeight: 500, color: "var(--ink)" },
  fileSize: { fontSize: 12.5, color: "var(--ink-soft)" },
  clearButton: {
    background: "none",
    border: "1px solid var(--hairline)",
    borderRadius: 3,
    padding: "6px 12px",
    fontSize: 13,
    color: "var(--ink-soft)",
    cursor: "pointer",
  },
  controls: {
    marginTop: 24,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "wrap",
    gap: 16,
  },
  lengthRow: { display: "flex", alignItems: "center", gap: 12 },
  lengthLabel: { fontSize: 13, color: "var(--ink-soft)" },
  lengthOptions: { display: "flex", gap: 6 },
  lengthPill: {
    border: "1px solid var(--hairline)",
    background: "var(--paper-raised)",
    borderRadius: 20,
    padding: "6px 14px",
    fontSize: 13,
    color: "var(--ink-soft)",
    cursor: "pointer",
  },
  lengthPillActive: {
    borderColor: "var(--mark)",
    color: "var(--mark)",
    background: "var(--mark-soft)",
  },
  primaryButton: {
    background: "var(--ink)",
    color: "var(--paper)",
    border: "none",
    borderRadius: 3,
    padding: "12px 22px",
    fontSize: 14.5,
    fontWeight: 500,
    cursor: "pointer",
  },
  error: {
    marginTop: 20,
    color: "var(--error)",
    fontSize: 14,
    borderLeft: "3px solid var(--error)",
    paddingLeft: 12,
  },
  result: {
    marginTop: 40,
    paddingTop: 28,
    borderTop: "1px solid var(--hairline)",
  },
  resultHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "baseline",
    marginBottom: 12,
  },
  resultEyebrow: {
    fontSize: 12.5,
    color: "var(--mark)",
    fontWeight: 600,
  },
  resultMeta: { fontSize: 12.5, color: "var(--ink-soft)" },
  summaryText: {
    fontFamily: "'Source Serif 4', Georgia, serif",
    fontSize: 18,
    lineHeight: 1.65,
    color: "var(--ink)",
    margin: "0 0 24px",
  },
  keyPoints: { marginTop: 8 },
  keyList: { margin: "10px 0 0", paddingLeft: 20 },
  keyItem: { fontSize: 15, lineHeight: 1.6, color: "var(--ink)", marginBottom: 8 },
};
