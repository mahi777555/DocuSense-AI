import "./globals.css";

export const metadata = {
  title: "Document Summary Assistant",
  description: "Upload a PDF or scanned image and get an instant smart summary.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
