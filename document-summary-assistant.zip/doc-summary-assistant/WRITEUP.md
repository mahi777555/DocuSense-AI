# Approach Write-up

I built Document Summary Assistant as a single Next.js 14 app so extraction, summarization,
and UI could all deploy together on Vercel with zero extra infrastructure.

The pipeline is two API routes. `/api/extract` branches on file type: PDFs go through
`pdf-parse`, images go through `tesseract.js` OCR — both run server-side since they need
Node APIs unavailable in the browser or Edge runtime. `/api/summarize` then sends the
extracted text to Claude with a length instruction (short/medium/long) and asks for
strict JSON back (summary + key points), which keeps the frontend simple to render.

The main design decision was resilience: rather than requiring an API key, the app checks
for `ANTHROPIC_API_KEY` and, if it's missing or the call fails, falls back to a small
extractive summarizer I wrote (word-frequency sentence scoring, no dependencies). This
means the app is fully demoable out of the box, and upgrades quality automatically once a
key is added — satisfying "free tier" without sacrificing a working default.

On the frontend, I kept state minimal (a handful of `useState` hooks), added explicit
loading stages ("Reading document…" / "Writing summary…") so users always know what's
happening, and validated file types both client- and server-side with clear error
messages instead of silent failures.
